package com.ashos.themes

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Special accent index meaning "take the colour from the wallpaper" (needs Android 12+). */
const val WALLPAPER_ACCENT = 99

data class AccentPreset(val name: String, val color: Color)

val AccentPresets = listOf(
    AccentPreset("Violet", Color(0xFF7C5CFF)),
    AccentPreset("Electric Blue", Color(0xFF2F80FF)),
    AccentPreset("Teal", Color(0xFF12B5A6)),
    AccentPreset("Rose", Color(0xFFF0508A)),
    AccentPreset("Amber", Color(0xFFF5A524)),
)

data class AshColors(
    val background: Color,
    val glass: Color,
    val glassBorder: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val secondary: Color,
    val isDark: Boolean,
)

private val LocalAshColors = staticCompositionLocalOf<AshColors> {
    error("AshTheme not provided")
}

object Ash {
    val colors: AshColors
        @Composable get() = LocalAshColors.current
}

private fun darkColors(accent: Color) = AshColors(
    background = Color(0xFF11131D),
    glass = Color.White.copy(alpha = 0.08f),
    glassBorder = Color.White.copy(alpha = 0.14f),
    textPrimary = Color(0xFFFFFFFF),
    textSecondary = Color(0xFFC4C6D4),
    accent = accent,
    secondary = Color(0xFF2F80FF), // Electric Blue
    isDark = true,
)

private fun lightColors(accent: Color) = AshColors(
    background = Color(0xFFF1F2F8),
    glass = Color.White.copy(alpha = 0.70f),
    glassBorder = Color.Black.copy(alpha = 0.06f),
    textPrimary = Color(0xFF202033),
    textSecondary = Color(0xFF56566D),
    accent = accent,
    secondary = Color(0xFFB8BCC8), // Silver
    isDark = false,
)

@Composable
fun AshTheme(
    mode: ThemeMode,
    accentIndex: Int,
    content: @Composable () -> Unit,
) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val context = LocalContext.current
    // accentIndex == WALLPAPER_ACCENT uses the phone's wallpaper colour (Android 12+ only).
    val accent = if (accentIndex == WALLPAPER_ACCENT && Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(context).primary else dynamicLightColorScheme(context).primary
    } else {
        (AccentPresets.getOrNull(accentIndex) ?: AccentPresets[0]).color
    }
    val colors = remember(dark, accent) { if (dark) darkColors(accent) else lightColors(accent) }

    val scheme = if (dark) {
        darkColorScheme(
            primary = accent,
            background = colors.background,
            surface = Color(0xFF1B1E2C),
            onBackground = colors.textPrimary,
            onSurface = colors.textPrimary,
        )
    } else {
        lightColorScheme(
            primary = accent,
            background = colors.background,
            surface = Color.White,
            onBackground = colors.textPrimary,
            onSurface = colors.textPrimary,
        )
    }

    // Keep status/navigation bar icons readable in both themes.
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    CompositionLocalProvider(LocalAshColors provides colors) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/** Translucent "glass" panel. No real blur in Phase 1 (cheap on a 5 GB device). */
@Composable
fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp)): Modifier {
    val c = Ash.colors
    return this
        .clip(shape)
        .background(c.glass)
        .border(1.dp, c.glassBorder, shape)
}

@Composable
fun AshBackground(content: @Composable () -> Unit) {
    val c = Ash.colors
    val tint = lerp(c.background, c.accent, if (c.isDark) 0.22f else 0.18f)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(c.background, tint))),
    ) {
        content()
    }
}
