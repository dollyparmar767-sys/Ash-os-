package com.ashos.apps

import android.content.ComponentName
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.core.graphics.drawable.toBitmap
import com.ashos.data.AppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Small in-memory cache (200 icons) so scrolling the drawer stays smooth and memory stays low. */
object IconCache {
    private val cache = LruCache<String, ImageBitmap>(200)
    fun get(key: String): ImageBitmap? = cache.get(key)
    fun put(key: String, bitmap: ImageBitmap) {
        cache.put(key, bitmap)
    }
}

@Composable
fun AppIcon(app: AppInfo, size: Dp) {
    val context = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }

    val bitmap by produceState<ImageBitmap?>(initialValue = IconCache.get(app.key), app.key) {
        if (value == null) {
            val loaded = withContext(Dispatchers.Default) {
                runCatching {
                    context.packageManager
                        .getActivityIcon(ComponentName(app.packageName, app.activityName))
                        .toBitmap(px, px)
                        .asImageBitmap()
                }.getOrNull()
            }
            if (loaded != null) {
                IconCache.put(app.key, loaded)
                value = loaded
            }
        }
    }

    val b = bitmap
    if (b != null) {
        Image(bitmap = b, contentDescription = app.label, modifier = Modifier.size(size))
    } else {
        Spacer(Modifier.size(size))
    }
}
