package com.ashos.data

data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
) {
    /** Unique id for one launchable activity. */
    val key: String get() = "$packageName/$activityName"
}
