package com.ashos.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ashos.themes.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "ash_settings")

enum class ClockFormat { SYSTEM, H12, H24 }

data class AshSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val accentIndex: Int = 0,
    /** Ordered list of AppInfo.key values pinned to the home dock. */
    val favorites: List<String> = emptyList(),
    val showBattery: Boolean = true,
    val clockFormat: ClockFormat = ClockFormat.SYSTEM,
)

class SettingsStore(private val context: Context) {

    private val themeKey = stringPreferencesKey("theme_mode")
    private val accentKey = intPreferencesKey("accent_index")
    private val favoritesKey = stringPreferencesKey("favorites")
    private val showBatteryKey = booleanPreferencesKey("show_battery")
    private val clockFormatKey = stringPreferencesKey("clock_format")

    val settings: Flow<AshSettings> = context.dataStore.data.map { p ->
        AshSettings(
            themeMode = runCatching { ThemeMode.valueOf(p[themeKey] ?: "SYSTEM") }
                .getOrDefault(ThemeMode.SYSTEM),
            accentIndex = p[accentKey] ?: 0,
            favorites = (p[favoritesKey] ?: "").split("|").filter { it.isNotBlank() },
            showBattery = p[showBatteryKey] ?: true,
            clockFormat = runCatching { ClockFormat.valueOf(p[clockFormatKey] ?: "SYSTEM") }
                .getOrDefault(ClockFormat.SYSTEM),
        )
    }

    suspend fun setShowBattery(show: Boolean) {
        context.dataStore.edit { it[showBatteryKey] = show }
    }

    suspend fun setClockFormat(format: ClockFormat) {
        context.dataStore.edit { it[clockFormatKey] = format.name }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[themeKey] = mode.name }
    }

    suspend fun setAccent(index: Int) {
        context.dataStore.edit { it[accentKey] = index }
    }

    suspend fun setFavorites(keys: List<String>) {
        context.dataStore.edit { it[favoritesKey] = keys.joinToString("|") }
    }
}
