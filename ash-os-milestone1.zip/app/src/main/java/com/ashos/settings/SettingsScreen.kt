package com.ashos.settings

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ashos.data.ClockFormat
import com.ashos.themes.AccentPresets
import com.ashos.themes.Ash
import com.ashos.themes.ThemeMode
import com.ashos.themes.WALLPAPER_ACCENT
import com.ashos.themes.glass

@Composable
fun SettingsScreen(
    themeMode: ThemeMode,
    accentIndex: Int,
    isDefaultLauncher: Boolean,
    showBattery: Boolean,
    clockFormat: ClockFormat,
    onThemeMode: (ThemeMode) -> Unit,
    onAccent: (Int) -> Unit,
    onShowBattery: (Boolean) -> Unit,
    onClockFormat: (ClockFormat) -> Unit,
    onSetDefault: () -> Unit,
    onOpenHomeSettings: () -> Unit,
    onBack: () -> Unit,
) {
    val c = Ash.colors

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = c.textPrimary)
            }
            Text("Settings", color = c.textPrimary, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // ---- Appearance ----
            SectionCard(title = "Appearance") {
                Text("Theme", color = c.textSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeChip("Auto", themeMode == ThemeMode.SYSTEM) { onThemeMode(ThemeMode.SYSTEM) }
                    ThemeChip("Light", themeMode == ThemeMode.LIGHT) { onThemeMode(ThemeMode.LIGHT) }
                    ThemeChip("Dark", themeMode == ThemeMode.DARK) { onThemeMode(ThemeMode.DARK) }
                }
                Spacer(Modifier.height(20.dp))
                Text("Accent colour", color = c.textSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AccentPresets.forEachIndexed { index, preset ->
                        val selected = index == accentIndex
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(preset.color)
                                .border(
                                    BorderStroke(if (selected) 3.dp else 1.dp, if (selected) c.textPrimary else c.glassBorder),
                                    CircleShape,
                                )
                                .clickable { onAccent(index) },
                        )
                    }
                    if (Build.VERSION.SDK_INT >= 31) {
                        // Wallpaper colour (Android 12+). Shown as a ring with a "W".
                        val selected = accentIndex == WALLPAPER_ACCENT
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(c.glass)
                                .border(
                                    BorderStroke(if (selected) 3.dp else 1.dp, if (selected) c.textPrimary else c.glassBorder),
                                    CircleShape,
                                )
                                .clickable { onAccent(WALLPAPER_ACCENT) },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("W", color = c.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                if (Build.VERSION.SDK_INT >= 31) {
                    Spacer(Modifier.height(6.dp))
                    Text("W = colour taken from your wallpaper", color = c.textSecondary, fontSize = 12.sp)
                }
            }

            // ---- Home screen preferences ----
            SectionCard(title = "Home screen preferences") {
                Text("Clock format", color = c.textSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ThemeChip("System", clockFormat == ClockFormat.SYSTEM) { onClockFormat(ClockFormat.SYSTEM) }
                    ThemeChip("12-hour", clockFormat == ClockFormat.H12) { onClockFormat(ClockFormat.H12) }
                    ThemeChip("24-hour", clockFormat == ClockFormat.H24) { onClockFormat(ClockFormat.H24) }
                }
                Spacer(Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("Show battery on home", color = c.textPrimary, fontSize = 15.sp)
                    Switch(checked = showBattery, onCheckedChange = onShowBattery)
                }
            }

            // ---- Home screen ----
            SectionCard(title = "Home screen") {
                Text(
                    text = if (isDefaultLauncher) {
                        "ASH OS is your default home app."
                    } else {
                        "ASH OS is not your default home app yet. Pressing the Home button will open your current launcher until you change this."
                    },
                    color = c.textSecondary,
                    fontSize = 14.sp,
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = if (isDefaultLauncher) "Change default home app" else "Set ASH OS as default",
                    color = c.textPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(c.accent.copy(alpha = 0.35f))
                        .clickable(onClick = onSetDefault)
                        .padding(vertical = 14.dp),
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "Open Android home app settings",
                    color = c.textPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, c.glassBorder, RoundedCornerShape(16.dp))
                        .clickable(onClick = onOpenHomeSettings)
                        .padding(vertical = 14.dp),
                )
            }

            // ---- About ----
            SectionCard(title = "About ASH OS") {
                Text("ASH OS 0.1.1 · Milestone 1", color = c.textPrimary, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Your Phone. Your Identity. Your Intelligence.",
                    color = c.textSecondary,
                    fontSize = 13.sp,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "ASH OS is a launcher. It sees the apps you have installed only to show and open them, and it collects and sends no data.",
                    color = c.textSecondary,
                    fontSize = 13.sp,
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    val c = Ash.colors
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(24.dp))
            .padding(18.dp),
    ) {
        Text(title, color = c.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = Ash.colors
    Text(
        text = label,
        color = if (selected) c.textPrimary else c.textSecondary,
        fontSize = 14.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) c.accent.copy(alpha = 0.45f) else c.glass)
            .border(1.dp, if (selected) c.accent else c.glassBorder, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
    )
}
