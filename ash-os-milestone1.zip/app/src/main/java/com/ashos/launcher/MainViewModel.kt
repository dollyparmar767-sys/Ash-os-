package com.ashos.launcher

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ashos.data.AppInfo
import com.ashos.data.AppRepository
import com.ashos.data.AshSettings
import com.ashos.data.ClockFormat
import com.ashos.data.SettingsStore
import com.ashos.navigation.Screen
import com.ashos.themes.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val store = SettingsStore(application)

    var screen by mutableStateOf(Screen.HOME)
        private set

    var isDefaultLauncher by mutableStateOf(false)
        private set

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps

    val settings: StateFlow<AshSettings> =
        store.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AshSettings())

    /** Pinned apps, in the order the user pinned them. Uninstalled apps drop out automatically. */
    val favorites: StateFlow<List<AppInfo>> =
        combine(_apps, settings) { apps, s ->
            s.favorites.mapNotNull { key -> apps.firstOrNull { it.key == key } }
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshApps()
        }
    }

    init {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(
            application, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED,
        )
        refreshApps()
        refreshDefault()
    }

    override fun onCleared() {
        getApplication<Application>().unregisterReceiver(packageReceiver)
        super.onCleared()
    }

    // ---- navigation ----
    fun goHome() { screen = Screen.HOME }
    fun openDrawer() { screen = Screen.DRAWER }
    fun openSettings() { screen = Screen.SETTINGS }

    // ---- apps ----
    fun refreshApps() {
        viewModelScope.launch {
            _apps.value = withContext(Dispatchers.IO) { repository.loadApps() }
        }
    }

    /** If the app can't be started (e.g. it was just uninstalled), the list is refreshed. */
    fun launch(app: AppInfo): Boolean {
        val ok = repository.launch(app)
        if (!ok) refreshApps()
        return ok
    }
    fun openAppInfo(app: AppInfo) = repository.openAppInfo(app)
    fun uninstall(app: AppInfo) = repository.uninstall(app)

    /** Returns false if the dock is full (max 5). */
    fun togglePin(app: AppInfo): Boolean {
        val current = settings.value.favorites
        val updated = if (app.key in current) {
            current - app.key
        } else {
            if (current.size >= MAX_FAVORITES) return false
            current + app.key
        }
        viewModelScope.launch { store.setFavorites(updated) }
        return true
    }

    // ---- settings ----
    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { store.setThemeMode(mode) }
    }

    fun setAccent(index: Int) {
        viewModelScope.launch { store.setAccent(index) }
    }

    fun setShowBattery(show: Boolean) {
        viewModelScope.launch { store.setShowBattery(show) }
    }

    fun setClockFormat(format: ClockFormat) {
        viewModelScope.launch { store.setClockFormat(format) }
    }

    fun refreshDefault() {
        val app = getApplication<Application>()
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolved = app.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
        isDefaultLauncher = resolved?.activityInfo?.packageName == app.packageName
    }

    companion object {
        const val MAX_FAVORITES = 5
    }
}
