package com.ashos.launcher

import android.app.role.RoleManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ashos.apps.DrawerScreen
import com.ashos.home.HomeScreen
import com.ashos.navigation.Screen
import com.ashos.settings.SettingsScreen
import com.ashos.themes.AshBackground
import com.ashos.themes.AshTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val roleRequest =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            viewModel.refreshDefault()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AshRoot(
                viewModel = viewModel,
                onSetDefault = ::requestDefaultLauncher,
                onOpenHomeSettings = ::openHomeSettings,
            )
        }
    }

    // Pressing the Home button while ASH OS is already running brings us back to the home screen.
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            viewModel.goHome()
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshDefault()
    }

    /** Opens Android's own "Home app" settings page, where the user picks the default launcher. */
    private fun openHomeSettings() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                this,
                "This phone has no direct page for it. Open Settings > Apps > Default apps > Home app.",
                Toast.LENGTH_LONG,
            ).show()
        }
    }

    /** Android 10+: ask via the system role dialog. Otherwise open the system home-app settings. */
    private fun requestDefaultLauncher() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    if (rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                        Toast.makeText(this, "ASH OS is already your home app", Toast.LENGTH_SHORT).show()
                    } else {
                        roleRequest.launch(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                    }
                    return
                }
            }
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                this,
                "Open Settings > Apps > Default apps > Home app and choose ASH OS",
                Toast.LENGTH_LONG,
            ).show()
        }
    }
}

@Composable
fun AshRoot(
    viewModel: MainViewModel,
    onSetDefault: () -> Unit,
    onOpenHomeSettings: () -> Unit,
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val apps by viewModel.apps.collectAsStateWithLifecycle()
    val favorites by viewModel.favorites.collectAsStateWithLifecycle()
    val context = LocalContext.current

    fun launchApp(app: com.ashos.data.AppInfo) {
        if (!viewModel.launch(app)) {
            Toast.makeText(context, "Couldn't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    AshTheme(mode = settings.themeMode, accentIndex = settings.accentIndex) {
        AshBackground {
            // On the home screen Back does nothing (like a normal launcher); elsewhere it returns home.
            BackHandler {
                if (viewModel.screen != Screen.HOME) viewModel.goHome()
            }

            Crossfade(
                targetState = viewModel.screen,
                animationSpec = tween(180),
                label = "screen",
            ) { screen ->
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        favorites = favorites,
                        showBattery = settings.showBattery,
                        clockFormat = settings.clockFormat,
                        onLaunch = ::launchApp,
                        onOpenDrawer = viewModel::openDrawer,
                        onOpenSettings = viewModel::openSettings,
                    )

                    Screen.DRAWER -> DrawerScreen(
                        apps = apps,
                        pinnedKeys = settings.favorites.toSet(),
                        onLaunch = ::launchApp,
                        onTogglePin = { app ->
                            if (!viewModel.togglePin(app)) {
                                Toast.makeText(
                                    context,
                                    "Dock is full (max ${MainViewModel.MAX_FAVORITES}). Unpin one first.",
                                    Toast.LENGTH_SHORT,
                                ).show()
                            }
                        },
                        onAppInfo = viewModel::openAppInfo,
                        onUninstall = viewModel::uninstall,
                        onClose = viewModel::goHome,
                    )

                    Screen.SETTINGS -> SettingsScreen(
                        themeMode = settings.themeMode,
                        accentIndex = settings.accentIndex,
                        isDefaultLauncher = viewModel.isDefaultLauncher,
                        showBattery = settings.showBattery,
                        clockFormat = settings.clockFormat,
                        onThemeMode = viewModel::setThemeMode,
                        onAccent = viewModel::setAccent,
                        onShowBattery = viewModel::setShowBattery,
                        onClockFormat = viewModel::setClockFormat,
                        onSetDefault = onSetDefault,
                        onOpenHomeSettings = onOpenHomeSettings,
                        onBack = viewModel::goHome,
                    )
                }
            }
        }
    }
}
