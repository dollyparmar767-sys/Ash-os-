package com.ashos.home

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.text.format.DateFormat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ashos.apps.AppIcon
import com.ashos.data.AppInfo
import com.ashos.data.ClockFormat
import com.ashos.themes.Ash
import com.ashos.themes.glass
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class BatteryInfo(val percent: Int, val charging: Boolean)

private fun readBattery(context: Context): BatteryInfo {
    // Passing null registers nothing; it just returns the last sticky battery broadcast.
    val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL
    val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
    return BatteryInfo(percent, charging)
}

@Composable
fun HomeScreen(
    favorites: List<AppInfo>,
    showBattery: Boolean,
    clockFormat: ClockFormat,
    onLaunch: (AppInfo) -> Unit,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val c = Ash.colors
    val context = LocalContext.current

    // Real clock: re-ticks at the start of every minute.
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000L - (value % 60_000L))
        }
    }
    val battery by produceState(initialValue = readBattery(context)) {
        while (true) {
            value = readBattery(context)
            delay(30_000L)
        }
    }

    val is24h = when (clockFormat) {
        ClockFormat.SYSTEM -> DateFormat.is24HourFormat(context)
        ClockFormat.H12 -> false
        ClockFormat.H24 -> true
    }
    val timeFormat = remember(is24h) { SimpleDateFormat(if (is24h) "HH:mm" else "h:mm", Locale.getDefault()) }
    val dateFormat = remember { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()) }

    var drag by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f },
                    onDragEnd = { if (drag < -140f) onOpenDrawer() },
                    onDragCancel = { drag = 0f },
                ) { _, dy -> drag += dy }
            },
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = c.textSecondary)
                }
            }

            Spacer(Modifier.height(36.dp))

            Text(
                text = timeFormat.format(Date(now)),
                color = c.textPrimary,
                fontSize = 84.sp,
                fontWeight = FontWeight.Light,
            )
            Text(
                text = dateFormat.format(Date(now)),
                color = c.textSecondary,
                fontSize = 18.sp,
            )

            Spacer(Modifier.height(24.dp))

            // Battery card (real data from the system battery broadcast); can be hidden in Settings
            if (showBattery) Row(
                modifier = Modifier
                    .glass(RoundedCornerShape(20.dp))
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .width(10.dp)
                        .height(10.dp)
                        .glass(CircleShape)
                        .padding(0.dp),
                )
                Spacer(Modifier.width(10.dp))
                val batteryText = if (battery.percent >= 0) {
                    "Battery ${battery.percent}%" + if (battery.charging) " · charging" else ""
                } else {
                    "Battery unavailable"
                }
                Text(batteryText, color = c.textPrimary, fontSize = 15.sp)
            }

            Box(Modifier.weight(1f))

            // Tap target for the drawer (swipe up also works)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenDrawer)
                    .padding(bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Open apps", tint = c.textSecondary)
                Text("Swipe up for apps", color = c.textSecondary, fontSize = 12.sp)
            }

            // Dock
            if (favorites.isEmpty()) {
                Text(
                    text = "Long-press an app in the drawer and choose \"Pin to dock\".",
                    color = c.textSecondary,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(28.dp))
                        .padding(20.dp),
                )
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .glass(RoundedCornerShape(28.dp))
                        .padding(vertical = 14.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    favorites.forEach { app ->
                        Column(
                            modifier = Modifier
                                .width(64.dp)
                                .clickable { onLaunch(app) },
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            AppIcon(app, 52.dp)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                app.label,
                                color = c.textPrimary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        }
    }
}
