package com.ashos.navigation

enum class Screen { HOME, DRAWER, SETTINGS }
