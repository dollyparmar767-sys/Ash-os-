# ASH OS — Progress Report

## Milestone 1 — Functional launcher (0.1.1)

Status: **code written, NOT yet compiled or run on a device.** Tick the last column after testing on your Realme 9i.

| Item | Written | Tested on device |
|---|---|---|
| Launcher activity (MAIN + HOME + DEFAULT, singleTask) | yes | |
| Real installed-app detection (PackageManager + `<queries>`) | yes | |
| App launching, safe failure (toast + list refresh) | yes | |
| Home: clock, date, battery card, dock, drawer button + swipe up | yes | |
| App drawer: A–Z, search, long-press (pin / app info / uninstall) | yes | |
| Dock favourites persisted (DataStore) | yes | |
| Home prefs persisted: clock format, show battery | yes | |
| Light / Dark / Auto theme + accent colours + wallpaper accent (Android 12+) | yes | |
| Set as default launcher (role dialog) + "Open Android home app settings" | yes | |
| Auto-refresh when apps are installed or removed | yes | |
| Gradle wrapper (Gradle 8.7) + GitHub Actions debug APK | yes | |

## Not started (waiting for milestone 1 to build and pass testing)
Bottom navigation, wallpapers, widgets, home customization mode, AI, Personal Space, Files, Control Center, automation.

## Known limits
- A launcher cannot replace Android or control protected system features.
- Theme may flash the default for a split second on cold start before saved settings load.
- No real blur yet (kept off for 5 GB RAM); glass look is translucent panels.
